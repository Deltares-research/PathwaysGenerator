# Run the app

To run the app from within this directory:

```
flet run .
```

To run the app as a website:

```
flet run --web .
```
